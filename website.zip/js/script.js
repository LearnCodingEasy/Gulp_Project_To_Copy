"use strict";console.log("Yes"),console.log("no"),console.log("no");
//# sourceMappingURL=script.js.map
